//1
let car = {
    model: 'Uno Mille EP', year: '1996', color: 'green',
}
//2
console.log(car.year)

//3
car.model = 'Fiat'

//4

let livro =  '{"Livro": "Sherlock Holmes", "Páginas": "211"}'
JSON.parse(livro)
console.log(livro)

//5
let fruta = 'abacaxi'
JSON.stringify(fruta)
console.log(fruta)

//6
let media = 0

let aluno1 = {
    nome: 'joao',
    notas: 10
}

let aluno2 = {
    nome: 'mike',
    notas: 8
}

let aluno3 = {
    nome: 'josefina',
    notas: 8
}

mediaGeral = (aluno1.notas + aluno2.notas + aluno3.notas) / 3
console.log(`A média das notas dos alunos ${aluno1.nome}, ${aluno2.nome}
e ${aluno3.nome} é: ${mediaGeral.toFixed(1)}`) 

//7
let chafariz = {
    agua1: 'water',
    agua2: 'walter',
    agua3: 'wutter'
}

chafariz = JSON.stringify(chafariz)
console.log(chafariz)

//8
let listaTarefas = {
    listaT1:{tarefa:'estudar', status:'concluida'},
    listaT2:{tarefa:'jogar', status:'naoConcluida'}, 
    listaT3:{tarefa:'comer', status:'concluida'} 
}

console.log('LISTA DE TAREFAS')
for(const property in listaTarefas){

console.log(tarefa[property], status[property])

    }


//9


//10
